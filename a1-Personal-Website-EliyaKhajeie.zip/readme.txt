--Readme document for *author*--

A reminder on academic integrity, as described in the syllabus.

In general, the course staff expects that you will look at code and examples from many online resources as part of the assignments, particularly to resolve syntax and understand frameworks. We expect that you'll use other libraries you find, and will even require it in some assignments. These practices are often critical to the work of developers today. The best developers are adept at interpreting the examples they see, customizing them to their specific situation, and citing their sources so they can find them later. We expect you to do the same.

While learning from examples is encouraged, attempting to pass an existing project or example from the web as your own is not allowed. If you ever have a question about what is or is not appropriate, feel free to ask the course staff!

Talking to classmates about class material, assignment requirements, etc. is a great way to verify ideas and get feedback. But this distinctly does *not* permit attempting to pass off someone else’s code as your own. Talking over ideas and approaches is allowed, but the work that you produce and submit must be your own.

1. How many assignment points do you believe you completed (replace the *'s with your numbers)?

12/13
- 1/1 Readme
- 2/2 Basic HTML content
- 2/2 Basic CSS styling
- 2/2 Advanced feature
- 2/3 Responsive layout
- 1/1 Passes validation checks
- 2/2 Embraces spirit of the assignment
I worked very hard on this not just to pass the tests and a valid layout, yet tried to make it look as clean and well put together as possible.
There are some placeholder images which were said to be okay, while I get some nicer photos of myself to then replace those images. The only
reason I don't know if itll be a 13/13 is due to the fact that I wasn't able to fully test it on different platforms yet wrote code that should
suffice for the use of multiple platforms. Being new to HTML I was having struggle testing these things. 

2. What (a) basic features, (b) CSS features, and (c) advanced features did you include in your portfolio?

(a) Basic features
1() At least one image with descritive alt attribute ((<img src="images/OIG (1).png" class="logo",alt="Portfolio background picture">) )

2() Appropriate headings and paragraph text: (<h1 class="sub-title">About Me</h1>
<p class ="about-text">Hello! I am a results-oriented Computer Science student at UCI...</p>

3() Links to external page(s):<a href="https://github.com/EliyaKhajeiee"><i class="fab fa-github"></i></a>
<a href="https://www.linkedin.com/in/"><i class="fab fa-linkedin"></i></a>

4() Semantic HTML tags like aside or footer: (<div class="copyright">
  <p>Copyright @ Eliya Khajeie.</p>
</div>) MY footer

5()  Adding custom icons from Google Material Icons or Font Awesome: (<i class="fa-solid fa-bars" onclick="openmenu()"></i>
<i class="fa-solid fa-xmark" onclick="closemenu()"></i>
)
6?() I have a single page yet I naviagte though the whole page using the top scroll menu to move onto different sections
)


(b) CSS features
1()Modifying padding and margins to indent content and enhance readability:
#portfolio{
    padding: 50px 0;
}
.work-list{    
    display: grid;
    grid-template-columns: repeat(auto-fit,minmax(250px,1fr));
    grid-gap: 40px;
    margin-top: 50px;}
I add padding and margins in multiple places in my code to make it visually more appealing.

2(Modifying link, text color, or other colors to be visually appealing:) 
body {
    background: #080808;
    color: #fff;
}

nav ul li a {
    color: #fff;
}

nav ul li a:hover::after {
    width: 100%;
}
I use different background colors in my links, and in places to hover over to make it visually better looking.

(c) Advanced features
1() Creating a more complex page layout, such as including a sidebar or navigation bar
I have a navigation bar at the top of my code which takes you to different sections of the page.



3. How long, in hours, did it take you to complete this assignment?
About 10-15 hours of complete coding, I have never used HTML so understanding most of it was hard.



4. What online resources did you consult when completing this assignment? (list specific URLs)
https://www.youtube.com/watch?v=0YFrGy_mzjY&t=86s

This is all I used, I followed along for a majority yet changed lots of it to make it my own taste and messed around with fonts and hover colors to change it 
so that I would understand how to do it. I made lots of different margins and paddings and modifyed it to my own style.



5. What classmates or other individuals did you consult as part of this assignment? What did you discuss?
I just had some friends from my highschool look at my website to make sure it was not only visually appealing to be but to others also. 



6. Is there anything special we need to know in order to run your code?
I don't think so. At the moment the contact section doesnt work, yet I dont believe this is a necessity for the code 

